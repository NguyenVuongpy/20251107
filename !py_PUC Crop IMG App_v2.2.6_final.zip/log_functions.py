# Import các thư viện cần thiết
import sys
import os
import pandas as pd
from datetime import datetime, timedelta
import shutil
import time
import glob
import numpy as np
from PIL import Image 
from PyQt6.QtWidgets import QMessageBox
import subprocess
import json

def get_script_dir():
    if getattr(sys, 'frozen', False):
        return os.path.dirname(sys.executable)
    else:
        return os.path.dirname(os.path.realpath(__file__))

script_dir = get_script_dir()

def authenticate_share(ip):
    """Xác thực quyền truy cập vào ổ share"""
    try:
        # Đọc config từ file
        config = {'lines': [], 'credentials': [{'username': 'user', 'password': '1'}]}
        if os.path.exists('app_config.json'):
            with open('app_config.json', 'r') as f:
                config = json.load(f)
        
        credentials = config.get('credentials', [{'username': 'user', 'password': '1'}])
        
        # Thử từng credential cho đến khi thành công
        for cred in credentials:
            username = cred.get('username')
            password = cred.get('password')
            
            command = f'net use \\\\{ip} /user:{username} {password}'
            result = subprocess.run(command, shell=True, capture_output=True, text=True)
            
            if result.returncode == 0:
                return True
                
        return False
    except Exception as e:
        print(f"Authentication error: {str(e)}")
        return False

def copy_logs_mono(start_date, end_date, selected_lines, selected_folder, folder_count=8, log_callback=None):
    csv_path = os.path.join(script_dir, 'IP_List.csv')
    df = pd.read_csv(csv_path, index_col=None, sep=',', header=0)
    #Drop NaN values in the 'PUC1 Name' column
    df = df.dropna(subset=['PUC1 Name']) 
    if selected_lines:
        df = df[df['PUC1 Name'].str.contains('|'.join(selected_lines))]
    
    pc_info = [(str(row['PUC1 Name']), str(row['PUC1 IP'])) for index, row in df.iterrows()]
    inaccessible_machines = set()
    authenticated_ips = set()

    for name, ip in pc_info:
        if ip not in authenticated_ips:
            if log_callback:
                log_callback(f"Authenticating access to {ip}...")
            
            if authenticate_share(ip):
                authenticated_ips.add(ip)
                if log_callback:
                    log_callback(f"Authentication successful for {ip}")
            else:
                if log_callback:
                    log_callback(f"Authentication failed for {ip}")
                inaccessible_machines.add(f'{name}\\{ip}')
                continue

        files_found = False
        current_date = start_date
        while current_date <= end_date:
            month_str = current_date.strftime('%m')
            day_str = current_date.strftime('%d')
            date_yyyymmdd = current_date.strftime('%Y%m%d')
            
            # Danh sách các đường dẫn cần thử theo thứ tự ưu tiên
            possible_paths = [
                # Cấu trúc cũ: {drive}:\POCB\HEX\{folder}\{MM}\{DD}
                f'\\\\{ip}\\d\\POCB\\HEX\\{selected_folder}\\{month_str}\\{day_str}',
                f'\\\\{ip}\\e\\POCB\\HEX\\{selected_folder}\\{month_str}\\{day_str}',
                
                # Cấu trúc mới: {drive}:\POCB\HEX\{YYYYMMDD}\{folder}
                f'\\\\{ip}\\d\\POCB\\HEX\\{date_yyyymmdd}\\{selected_folder}',
                f'\\\\{ip}\\e\\POCB\\HEX\\{date_yyyymmdd}\\{selected_folder}'
            ]
            
            src_dir = None
            for path in possible_paths:
                if os.path.exists(path):
                    src_dir = path
                    if log_callback:
                        log_callback(f"Found source directory: {src_dir}")
                    break
            
            if not src_dir:
                if log_callback:
                    log_callback(f"Source directory not found for {name}\\{ip} on {current_date.strftime('%Y-%m-%d')}")
                current_date += timedelta(days=1)
                continue
                
            dest_dir = os.path.join(script_dir, 'PUC1 Crop', name)

            try:
                if os.path.exists(src_dir):
                    subfolders = [f for f in os.listdir(src_dir) if os.path.isdir(os.path.join(src_dir, f))]
                    subfolders = subfolders[:int(folder_count)]

                    for folder in subfolders:
                        folder_path = os.path.join(src_dir, folder)
                        # Chỉ lấy các file .tif và không lấy file có đuôi "_ori.tif"
                        tif_files = [f for f in os.listdir(folder_path) 
                                    if f.endswith('.tif') and not f.endswith('_ori.tif')]

                        if tif_files:
                            files_found = True
                            if not os.path.exists(dest_dir):
                                os.makedirs(dest_dir)
                            
                            for filename in tif_files:
                                src_file = os.path.join(folder_path, filename)

                                # Tạo tên file mới
                                folder_name = folder.split('_')[0]  # Lấy phần tên trước dấu '_'
                                parts = filename.split('_')
                                # Lấy các phần cần thiết từ tên file
                                step_info = '_'.join(parts[:2]) 
                                color_info = parts[2]            
                                
                                # Tạo tên file mới
                                new_filename = f"{folder_name}_{step_info}_{color_info}.tif"
                                dest_file = os.path.join(dest_dir, new_filename)

                                shutil.copy2(src_file, dest_file)
                                if log_callback:
                                    log_callback(f"Copied: {dest_file}")
            except Exception as e:
                if f'{name}\\{ip}' not in inaccessible_machines:
                    inaccessible_machines.add(f'{name}\\{ip}')
                    if log_callback:
                        log_callback(f"Error accessing {name}\\{ip}: {str(e)}")
            
            current_date += timedelta(days=1)
        
        if not files_found:
            if log_callback:
                log_callback(f"No .tif files found for {name}\\{ip} in the specified date range")

    if inaccessible_machines:
        message = 'The following machines were inaccessible:\n' + '\n'.join(sorted(inaccessible_machines))
        if log_callback:
            log_callback(message)
        QMessageBox.warning(None, 'Warning', message)
    else:
        if log_callback:
            log_callback('All machines were accessible.')
        QMessageBox.information(None, 'Success', 'All machines were accessible.')


def copy_logs_color(start_date, end_date, selected_lines, selected_folder, folder_count=8, log_callback=None):
    csv_path = os.path.join(script_dir, 'IP_List.csv')
    df = pd.read_csv(csv_path, index_col=None, sep=',', header=0)
    #Drop NaN values in the 'PUC2 Name' column
    df = df.dropna(subset=['PUC2 Name'])    
    if selected_lines:
        df = df[df['PUC2 Name'].str.contains('|'.join(selected_lines))]
    
    pc_info = [(str(row['PUC2 Name']), str(row['PUC2 IP'])) for index, row in df.iterrows()]
    inaccessible_machines = set()
    authenticated_ips = set()

    for name, ip in pc_info:
        if ip not in authenticated_ips:
            if log_callback:
                log_callback(f"Authenticating access to {ip}...")
            
            if authenticate_share(ip):
                authenticated_ips.add(ip)
                if log_callback:
                    log_callback(f"Authentication successful for {ip}")
            else:
                if log_callback:
                    log_callback(f"Authentication failed for {ip}")
                inaccessible_machines.add(f'{name}\\{ip}')
                continue

        files_found = False
        current_date = start_date
        while current_date <= end_date:
            month_str = current_date.strftime('%m')
            day_str = current_date.strftime('%d')
            date_yyyymmdd = current_date.strftime('%Y%m%d')
            
            # Danh sách các đường dẫn cần thử theo thứ tự ưu tiên
            possible_paths = [
                # Cấu trúc cũ: {drive}:\POCB\HEX\{folder}\{MM}\{DD}
                f'\\\\{ip}\\d\\POCB\\HEX\\{selected_folder}\\{month_str}\\{day_str}',
                f'\\\\{ip}\\e\\POCB\\HEX\\{selected_folder}\\{month_str}\\{day_str}',
                
                # Cấu trúc mới: {drive}:\POCB\HEX\{YYYYMMDD}\{folder}
                f'\\\\{ip}\\d\\POCB\\HEX\\{date_yyyymmdd}\\{selected_folder}',
                f'\\\\{ip}\\e\\POCB\\HEX\\{date_yyyymmdd}\\{selected_folder}'
            ]
            
            src_dir = None
            for path in possible_paths:
                if os.path.exists(path):
                    src_dir = path
                    if log_callback:
                        log_callback(f"Found source directory: {src_dir}")
                    break
            
            if not src_dir:
                if log_callback:
                    log_callback(f"Source directory not found for {name}\\{ip} on {current_date.strftime('%Y-%m-%d')}")
                current_date += timedelta(days=1)
                continue
                
            dest_dir = os.path.join(script_dir, 'PUC2 Crop', name)

            try:
                if os.path.exists(src_dir):
                    subfolders = [f for f in os.listdir(src_dir) if os.path.isdir(os.path.join(src_dir, f))]
                    subfolders = subfolders[:int(folder_count)]

                    for folder in subfolders:
                        folder_path = os.path.join(src_dir, folder)
                        # Chỉ lấy các file .tif và không lấy file có đuôi "_ori.tif"
                        tif_files = [f for f in os.listdir(folder_path) 
                                    if f.endswith('.tif') and not f.endswith('_ori.tif')]

                        if tif_files:
                            files_found = True
                            if not os.path.exists(dest_dir):
                                os.makedirs(dest_dir)
                            
                            for filename in tif_files:
                                src_file = os.path.join(folder_path, filename)

                                # Tạo tên file mới
                                folder_name = folder.split('_')[0]  # Lấy phần tên trước dấu '_'
                                parts = filename.split('_')
                                # Lấy các phần cần thiết từ tên file
                                step_info = '_'.join(parts[:2]) 
                                color_info = parts[2]            
                                
                                # Tạo tên file mới
                                new_filename = f"{folder_name}_{step_info}_{color_info}.tif"
                                dest_file = os.path.join(dest_dir, new_filename)

                                shutil.copy2(src_file, dest_file)
                                if log_callback:
                                    log_callback(f"Copied: {dest_file}")
            except Exception as e:
                if f'{name}\\{ip}' not in inaccessible_machines:
                    inaccessible_machines.add(f'{name}\\{ip}')
                    if log_callback:
                        log_callback(f"Error accessing {name}\\{ip}: {str(e)}")
            
            current_date += timedelta(days=1)
        
        if not files_found:
            if log_callback:
                log_callback(f"No .tif files found for {name}\\{ip} in the specified date range")

    if inaccessible_machines:
        message = 'The following machines were inaccessible:\n' + '\n'.join(sorted(inaccessible_machines))
        if log_callback:
            log_callback(message)
        QMessageBox.warning(None, 'Warning', message)
    else:
        if log_callback:
            log_callback('All machines were accessible.')
        QMessageBox.information(None, 'Success', 'All machines were accessible.')