from PyQt6.QtWidgets import QWidget, QVBoxLayout, QPushButton, QLabel, QCalendarWidget
from PyQt6.QtCore import Qt, QPoint, QDate
from ui.custom_calendar import CustomCalendar

class CollapsibleCalendar(QWidget):
    def __init__(self, title, parent=None):
        super().__init__(parent)
        self.title = title
        self.is_expanded = False
        self.setup_ui()

    def setup_ui(self):
        self.layout = QVBoxLayout(self)
        self.layout.setContentsMargins(0, 0, 0, 0)
        self.layout.setSpacing(0)

        # Button để mở calendar
        self.toggle_button = QPushButton(self.title)
        self.toggle_button.setStyleSheet("""
            QPushButton {
                text-align: left;
                padding: 8px;
                background-color: white;
                border: 1px solid #ccc;
                border-radius: 4px;
            }
            QPushButton:hover {
                background-color: #f0f0f0;
            }
        """)
        self.toggle_button.clicked.connect(self.toggle_calendar)

        # Calendar widget
        self.calendar = CustomCalendar()
        self.calendar.setWindowFlags(Qt.WindowType.Popup)
        self.calendar.clicked.connect(self.calendar_clicked)
        
        # Thiết lập ngày hiện tại
        current_date = QDate.currentDate()
        self.calendar.setSelectedDate(current_date)
        
        # Label hiển thị ngày đã chọn
        self.date_label = QLabel()
        self.date_label.setStyleSheet("""
            QLabel {
                padding: 4px;
                color: #666;
            }
        """)
        self.calendar.selectionChanged.connect(self.update_date_label)

        self.layout.addWidget(self.toggle_button)
        self.layout.addWidget(self.date_label)

        # Cập nhật hiển thị ngày hiện tại trên button
        self.toggle_button.setText(f"{self.title}: {current_date.toString('yyyy-MM-dd')}")

    def toggle_calendar(self):
        if not self.calendar.isVisible():
            pos = self.toggle_button.mapToGlobal(QPoint(0, self.toggle_button.height()))
            self.calendar.move(pos)
            self.calendar.show()
        else:
            self.calendar.hide()

    def calendar_clicked(self):
        self.calendar.hide()
        self.update_date_label()

    def update_date_label(self):
        selected_date = self.calendar.selectedDate()
        self.date_label.setText(f"Selected: {selected_date.toString('yyyy-MM-dd')}")
        self.toggle_button.setText(f"{self.title}: {selected_date.toString('yyyy-MM-dd')}")

    def get_selected_date(self):
        return self.calendar.selectedDate()

    def set_selected_date(self, date):
        self.calendar.setSelectedDate(date)
        self.update_date_label()

    def hideEvent(self, event):
        self.calendar.hide()
        super().hideEvent(event)