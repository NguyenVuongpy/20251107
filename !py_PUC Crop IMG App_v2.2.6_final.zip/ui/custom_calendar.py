from PyQt6.QtWidgets import QCalendarWidget
from PyQt6.QtGui import QPainter, QColor, QPen
from PyQt6.QtCore import Qt, QDate

class CustomCalendar(QCalendarWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.min_date = None
        self.setStyleSheet("""
            QCalendarWidget QToolButton {
                color: black;
                background-color: #f0f0f0;
            }
            QCalendarWidget QMenu {
                background-color: white;
            }
            QCalendarWidget QSpinBox {
                background-color: white;
            }
            QCalendarWidget QAbstractItemView:enabled {
                background-color: white;
            }
            QCalendarWidget QAbstractItemView:disabled {
                color: #808080;
            }
        """)

    def paintCell(self, painter, rect, date):
        super().paintCell(painter, rect, date)
        if date == self.selectedDate():
            painter.save()
            painter.setPen(Qt.PenStyle.NoPen)
            painter.setBrush(QColor(52, 152, 219))  # Màu xanh nổi bật (#3498db)
            painter.drawRect(rect)
            painter.setPen(QColor(255, 255, 255))  # Màu trắng cho chữ
            painter.drawText(rect, Qt.AlignmentFlag.AlignCenter, str(date.day()))
            painter.restore()
        elif self.min_date and date < self.min_date:
            painter.save()
            painter.setPen(QPen(Qt.GlobalColor.red, 1, Qt.PenStyle.SolidLine))
            painter.drawLine(rect.topLeft(), rect.bottomRight())
            painter.drawLine(rect.topRight(), rect.bottomLeft())
            painter.restore()

    def setMinimumDate(self, date):
        super().setMinimumDate(date)
        self.min_date = date
        self.updateCells()
