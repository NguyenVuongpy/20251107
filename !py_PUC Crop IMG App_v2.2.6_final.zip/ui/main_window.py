from PyQt6.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, QLabel, 
                           QTextEdit, QFrame, QGridLayout, QCheckBox, QMessageBox, 
                           QApplication, QDialog, QComboBox, QCalendarWidget, QGroupBox, 
                           QTableWidget, QTableWidgetItem, QGraphicsDropShadowEffect, QLineEdit, QGraphicsBlurEffect)
from PyQt6.QtCore import Qt, QDate, QSize
from PyQt6.QtGui import QScreen, QIcon, QFont, QColor
from ui.custom_widgets import HoverButton, GrayHoverButton
from ui.custom_calendar import CustomCalendar
from ui.collapsible_calendar import CollapsibleCalendar
from log_functions import copy_logs_mono, copy_logs_color, get_script_dir
from datetime import datetime
import sys
import os
from ui.line_manager_dialog import LineManagerDialog
import rc.icons
import json
from ui.intensity_dialog import IntensityDialog
from PyQt6 import QtCore, QtGui, QtWidgets
from PyQt6.QtCore import Qt
import combined_detector


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("PUC Application")
        self.resize(1280, 780)
        self.setWindowIcon(QIcon(":/icons/app_icon.png"))
        
        self.script_dir = get_script_dir()
        
        # Load config khi khởi tạo
        self.load_config()
        self.setup_ui()
        
        # Khởi tạo các cửa sổ detector
        self.all_in_one_detector = None

    def create_button(self, text, icon_path, tooltip, callback, style):
        """Tạo button với các thuộc tính chung"""
        button = HoverButton(text)
        button.setIcon(QIcon(icon_path))
        button.setIconSize(QSize(26, 26))
        button.setStyleSheet(style)
        button.clicked.connect(callback)
        if tooltip:
            button.setToolTip(tooltip)
        return button

    def create_frame(self, height=None, style=None):
        """Tạo frame với style chung"""
        frame = QFrame()
        if height:
            frame.setFixedHeight(height)
        if style:
            frame.setStyleSheet(style)
        return frame

    def create_label(self, text, style=None):
        """Tạo label với style chung"""
        label = QLabel(text)
        if style:
            label.setStyleSheet(style)
        return label

    def create_combo_box(self, items, style=None):
        """Tạo combobox với style chung"""
        combo = QComboBox()
        combo.addItems(items)
        if style:
            combo.setStyleSheet(style)
        return combo

    def create_line_edit(self, default_text, style=None):
        """Tạo line edit với style chung"""
        line_edit = QLineEdit(default_text)
        if style:
            line_edit.setStyleSheet(style)
        return line_edit

    def create_checkbox(self, text, callback):
        """Tạo checkbox với style chung"""
        checkbox = QCheckBox(text)
        checkbox.setIcon(QIcon(":/icons/line.png"))
        checkbox.setIconSize(QSize(16, 16))
        checkbox.setStyleSheet("""
            QCheckBox {
                padding: 2px;
                spacing: 5px;
                min-width: 100px;
                max-width: 120px;
            }
            QCheckBox:hover {
                background-color: #e3e8f0;
                border-radius: 4px;
            }
        """)
        checkbox.stateChanged.connect(callback)
        return checkbox

    def create_button_layout(self, buttons, spacing=10):
        """Tạo layout cho các button"""
        layout = QHBoxLayout()
        layout.setSpacing(spacing)
        for button in buttons:
            layout.addWidget(button)
        return layout

    def load_config(self):
        """Load all configurations from file"""
        try:
            default_config = {
                'lines': ['501 Line', '502 Line', '503 Line', '504 Line'],
                'credentials': [{'username': 'user', 'password': '1'}],
                'mono_folders': [
                    "X2146A_P2_Mono_DEV_Glossy_ver1",
                    "X2146A_P2_Mono_DEV_Matte_ver1", 
                    "X2146A_UPS_Mono_DEV_Glossy_ver1",
                    "X2146A_UPS_Mono_DEV_Matte_ver1"
                ],
                'color_folders': [
                    "X2146A-P2-Color-DEV-Glossy-ver1",
                    "X2146A-P2-Color-DEV-Matte-ver1",
                    "X2146A-UPS-Color-DEV-Glossy-ver1", 
                    "X2146A-UPS-Color-DEV-Matte-ver1"
                ],
                'folder_count': 8
            }
            
            if os.path.exists('app_config.json'):
                with open('app_config.json', 'r') as f:
                    config = json.load(f)
                    # Update các giá trị từ file config
                    self.lines = config.get('lines', default_config['lines'])
                    self.credentials = config.get('credentials', default_config['credentials'])
                    self.mono_folders = config.get('mono_folders', default_config['mono_folders'])
                    self.color_folders = config.get('color_folders', default_config['color_folders'])
                    self.folder_count = config.get('folder_count', default_config['folder_count'])
            else:
                # Sử dụng giá trị mặc định nếu không có file
                self.lines = default_config['lines']
                self.credentials = default_config['credentials']
                self.mono_folders = default_config['mono_folders']
                self.color_folders = default_config['color_folders']
                self.folder_count = default_config['folder_count']
                
                # Tạo file config mới với giá trị mặc định
                with open('app_config.json', 'w') as f:
                    json.dump(default_config, f, indent=4)
                    
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Error loading config: {str(e)}")
            # Sử dụng giá trị mặc định nếu có lỗi
            self.lines = default_config['lines']
            self.credentials = default_config['credentials']
            self.mono_folders = default_config['mono_folders']
            self.color_folders = default_config['color_folders']
            self.folder_count = default_config['folder_count']

    def setup_ui(self):
        # Main widget and layout
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)
        main_layout.setSpacing(20)
        main_layout.setContentsMargins(30, 30, 30, 30)

        # Header container với thiết kế hiện đại hơn
        header_container = QtWidgets.QWidget()
        header_container.setFixedHeight(110)  # Tăng chiều cao
        header_container.setStyleSheet("""
            QWidget {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, 
                                        stop:0 #1f6692, stop:0.5 #3498db, stop:1 #5dade2);
                border-radius: 15px;
                margin: 5px;
            }
        """)

        # Thêm outer glow effect cho header (bóng đổ mạnh hơn)
        header_shadow = QtWidgets.QGraphicsDropShadowEffect()
        header_shadow.setBlurRadius(40)  # Tăng độ mờ
        header_shadow.setXOffset(0)
        header_shadow.setYOffset(6)  # Tăng độ dịch xuống để làm nổi bật hơn
        header_shadow.setColor(QtGui.QColor(52, 152, 219, 120))  # Tăng opacity của bóng
        header_container.setGraphicsEffect(header_shadow)

        header_layout = QtWidgets.QHBoxLayout(header_container)
        header_layout.setContentsMargins(30, 15, 30, 15)
        header_layout.setSpacing(20)

        # Icon trong header với đổ bóng
        icon_button = QtWidgets.QPushButton()
        icon_button.setFixedSize(90, 90)
        icon_button.setCursor(QtGui.QCursor(QtCore.Qt.CursorShape.PointingHandCursor))
        icon_button.setStyleSheet("""
            QPushButton {
                background: transparent;
                border: none;
                border-radius: 45px;
                padding: 10px;
            }
        """)
        
        # Tạo shadow effect cho icon button với độ đậm hơn
        icon_shadow = QtWidgets.QGraphicsDropShadowEffect()
        icon_shadow.setBlurRadius(15)
        icon_shadow.setXOffset(3)
        icon_shadow.setYOffset(3)
        icon_shadow.setColor(QtGui.QColor(0, 0, 0, 80))  # Tăng độ đậm của shadow
        icon_button.setGraphicsEffect(icon_shadow)
        
        # Set icon cho button với kích thước lớn hơn
        icon = QtGui.QIcon(":/icons/app_icon.png")
        icon_button.setIcon(icon)
        icon_button.setIconSize(QtCore.QSize(85, 85))  # Tăng kích thước icon
        
        # Thêm icon button vào header layout
        header_layout.addWidget(icon_button)


        # Text container
        text_container = QtWidgets.QWidget()
        text_container.setStyleSheet("""
            QWidget {
                background: transparent;
            }
        """)
        text_layout = QtWidgets.QVBoxLayout(text_container)
        text_layout.setSpacing(5)

        title_label = QtWidgets.QLabel("PUC Application")
        title_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignLeft)
        title_label.setFont(QtGui.QFont("Segoe UI", 22, QtGui.QFont.Weight.Bold))
        title_label.setStyleSheet("""
            color: white;
            padding: 0;
            margin: 0;
            letter-spacing: 1px;
        """)

        subtitle_label = QtWidgets.QLabel("PUC Crop Image Analysis Tool")
        subtitle_label.setFont(QtGui.QFont("Segoe UI", 9, QtGui.QFont.Weight.Bold))
        subtitle_label.setStyleSheet("""
            color: rgba(255, 255, 255, 0.95);
            margin-top: 0px;
            padding: 0;
            letter-spacing: 0.5px;
        """)

        text_layout.addWidget(title_label)
        text_layout.addWidget(subtitle_label)
        header_layout.addWidget(text_container)

        header_layout.addStretch()

        # Container cho version và setting
        version_container = QHBoxLayout()
        version_container.setSpacing(15)

        # Version label với thiết kế đơn giản
        version_label = QtWidgets.QLabel("⚡ v2.2.6 Smart Phone \n 'Optic Compensation Dev Team'")
        version_label.setAlignment(QtCore.Qt.AlignmentFlag.AlignRight | QtCore.Qt.AlignmentFlag.AlignBottom)
        version_label.setFont(QtGui.QFont("Segoe UI", 9))
        version_label.setStyleSheet("""
            color: rgba(255, 255, 255, 0.9);
            background: rgba(255, 255, 255, 0.1);
            border-radius: 8px;
            padding: 8px;
        """)

        # Setting button với thiết kế mới nổi bật hơn
        manage_lines_button = HoverButton("")
        manage_lines_button.setIcon(QIcon(":/icons/setting.png"))
        manage_lines_button.setIconSize(QSize(50, 50))
        manage_lines_button.clicked.connect(self.manage_lines)
        manage_lines_button.setStyleSheet("""
            QPushButton {
                background-color: rgba(255, 255, 255, 0.15);
                border: 2px solid rgba(255, 255, 255, 0.8);
                border-radius: 6px;
                padding: 6px;
                min-width: 50px;
                max-width: 50px;
                min-height: 50px;
                max-height: 50px;
            }
            QPushButton:hover {
                background-color: rgba(255, 255, 255, 0.25);
                border: 2px solid white;
            }
            QPushButton:pressed {
                background-color: rgba(255, 255, 255, 0.1);
                border: 2px solid rgba(255, 255, 255, 0.7);
            }
        """)

        # Thêm shadow effect mạnh hơn cho button
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(15)
        shadow.setXOffset(0)
        shadow.setYOffset(3)
        shadow.setColor(QColor(0, 0, 0, 100))
        manage_lines_button.setGraphicsEffect(shadow)

        # Thêm tooltip rõ ràng hơn
        manage_lines_button.setToolTip("Open Settings\n\n"
                                      "Features:\n"
                                      "- Manage Lines (501, 502, etc.)\n"
                                      "- Configure User Credentials\n"
                                      "- Manage Folders")

        version_container.addWidget(version_label)
        version_container.addWidget(manage_lines_button)

        header_layout.addLayout(version_container)

        main_layout.addWidget(header_container)

        # Content section với tỷ lệ mới
        content_layout = QHBoxLayout()
        content_layout.setSpacing(20)

        # Left panel (thu nhỏ lại)
        left_panel = QFrame()
        left_panel.setFixedWidth(670)  # Mở rộng panel trái để đủ 4 nút detector
        left_panel.setStyleSheet("""
            QFrame {
                background-color: white;
                border: 2px solid #e3e8f0;
                border-radius: 12px;
                padding: 15px;
            }
        """)
        left_layout = QVBoxLayout(left_panel)
        left_layout.setSpacing(15)

        # Calendar section
        calendar_container = QFrame()
        calendar_container.setStyleSheet("""
            QFrame {
                background-color: #f8f9fa;
                border: 1px solid #e3e8f0;
                border-radius: 8px;
                padding: 12px;
            }
        """)
        
        # Định nghĩa icon_size ngay từ đầu
        icon_size = QSize(28, 28)  # ặt kích thước icon mong muốn

        calendar_layout = QGridLayout()
        self.cal_start = CollapsibleCalendar("Select Start Date")
        self.cal_start.toggle_button.setIcon(QIcon(":/icons/calendar.png"))
        self.cal_start.toggle_button.setIconSize(QSize(20, 20))
        
        self.cal_end = CollapsibleCalendar("Select End Date")
        self.cal_end.toggle_button.setIcon(QIcon(":/icons/calendar.png"))
        self.cal_end.toggle_button.setIconSize(QSize(20, 20))
        
        # Kết nối signals với slots
        self.cal_start.calendar.selectionChanged.connect(self.update_start_date)
        self.cal_end.calendar.selectionChanged.connect(self.update_end_date)
        
        calendar_layout.addWidget(self.cal_start, 0, 0)
        calendar_layout.addWidget(self.cal_end, 0, 1)
        left_layout.addLayout(calendar_layout)

        # Line Selection với checkboxes
        checkbox_container = QFrame()
        checkbox_container.setObjectName("checkbox_container")
        checkbox_container.setStyleSheet("""
            QFrame {
                background-color: #f8f9fa;
                border: 1px solid #e3e8f0;
                border-radius: 8px;
                padding: 8px;
            }
        """)

        # Tạo layout chính cho container
        main_checkbox_layout = QVBoxLayout(checkbox_container)
        main_checkbox_layout.setSpacing(8)
        main_checkbox_layout.setContentsMargins(10, 5, 10, 5)

        # Header layout chứ chứa title
        header_layout = QHBoxLayout()

        # Title cho phần checkbox
        title_label = QLabel("Line Selection")
        title_label.setStyleSheet("""
            QLabel {
                color: #2c3e50;
                font-weight: bold;
                font-size: 11px;
            }
        """)
        header_layout.addWidget(title_label)

        # Thêm header layout vào main layout
        main_checkbox_layout.addLayout(header_layout)

        # Grid layout cho checkboxes
        grid_layout = QGridLayout()
        grid_layout.setSpacing(15)
        grid_layout.setObjectName("grid_layout")

        # Thêm các checkbox vào grid layout
        self.line_checkboxes = {}
        current_row = 0
        current_col = 0
        MAX_COLUMNS = 5

        for line in self.lines:
            checkbox = QCheckBox(line)
            checkbox.setIcon(QIcon(":/icons/line.png"))
            checkbox.setIconSize(QSize(16, 16))
            checkbox.setStyleSheet("""
                QCheckBox {
                    padding: 2px;
                    spacing: 5px;
                    min-width: 100px;
                    max-width: 120px;
                }
                QCheckBox:hover {
                    background-color: #e3e8f0;
                    border-radius: 4px;
                }
            """)
            checkbox.stateChanged.connect(self.update_button_states)
            self.line_checkboxes[line] = checkbox
            
            grid_layout.addWidget(checkbox, current_row, current_col)
            current_col += 1
            if current_col >= MAX_COLUMNS:
                current_col = 0
                current_row += 1

        # Thêm grid layout vào main layout
        main_checkbox_layout.addLayout(grid_layout)

        left_layout.addWidget(checkbox_container)

        # Tạo comboboxes trước khi sử dụng
        self.mono_combo = QComboBox()
        self.mono_combo.addItems(self.mono_folders)
        self.mono_combo.setCurrentText(self.mono_folders[0])

        self.color_combo = QComboBox()
        self.color_combo.addItems(self.color_folders)
        self.color_combo.setCurrentText(self.color_folders[0])

        # Folder Selection Section với style mới
        folder_frame = QFrame()
        folder_frame.setFixedHeight(110)  # Giảm chiều cao
        folder_frame.setStyleSheet("""
            QFrame {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, 
                                          stop:0 #f5f6fa, stop:1 #f8f9fa);
                border: 1px solid #dcdde1;
                border-radius: 8px;
                padding: 8px;
            }
            QLabel {
                color: #2c3e50;
                font-weight: bold;
                font-size: 10px;
                margin-bottom: 2px;
            }
            QComboBox {
                background-color: white;
                border: 1px solid #3498db;
                border-radius: 4px;
                padding: 4px 25px 4px 10px;
                min-width: 250px;
                max-width: 250px;
                min-height: 22px;
                font-size: 11px;
                color: #2c3e50;
            }
            QComboBox:hover {
                border-color: #2980b9;
                background-color: #f8f9fa;
            }
            QComboBox:focus {
                border-color: #2980b9;
                background-color: white;
            }
            QComboBox::drop-down {
                border: none;
                width: 20px;
            }
            QComboBox::down-arrow {
                image: url(:/icons/down_arrow.png);
                width: 10px;
                height: 10px;
            }
            QComboBox QAbstractItemView {
                background-color: white;
                border: 1px solid #3498db;
                border-radius: 4px;
                selection-background-color: #3498db;
                selection-color: white;
                padding: 4px;
            }
            QComboBox QAbstractItemView::item {
                min-height: 20px;
                padding: 4px 8px;
                border-bottom: 1px solid #ecf0f1;
            }
            QComboBox QAbstractItemView::item:hover {
                background-color: #f1f2f6;
                color: #2c3e50;
            }
            QComboBox QAbstractItemView::item:selected {
                background-color: #3498db;
                color: white;
            }
        """)

        folder_layout = QGridLayout(folder_frame)
        folder_layout.setSpacing(0)
        folder_layout.setContentsMargins(8, 5, 8, 5)

        # 1stPUC Folder
        mono_label = QLabel("1stPUC Program Name:")
        self.mono_combo = QComboBox()
        self.mono_combo.addItems(self.mono_folders)
        
        # 2ndPUC Folder
        color_label = QLabel("2ndPUC Program Name:")
        self.color_combo = QComboBox()
        self.color_combo.addItems(self.color_folders)
        
        # Add to grid layout
        folder_layout.addWidget(mono_label, 0, 0)
        folder_layout.addWidget(self.mono_combo, 0, 1)
        folder_layout.addWidget(color_label, 1, 0)
        folder_layout.addWidget(self.color_combo, 1, 1)

        left_layout.addWidget(folder_frame)

        # Folder Count Selection
        folder_count_frame = QFrame()
        folder_count_frame.setFixedHeight(50)
        folder_count_frame.setStyleSheet("""
            QFrame {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, 
                                          stop:0 #f5f6fa, stop:1 #f8f9fa);
                border: 1px solid #dcdde1;
                border-radius: 8px;
                padding: 8px;
            }
        """)

        folder_count_layout = QHBoxLayout(folder_count_frame)
        folder_count_layout.setContentsMargins(8, 0, 8, 0)

        folder_count_label = QLabel("Number of folders to copy:")
        folder_count_label.setStyleSheet("""
            QLabel {
                color: #2c3e50;
                font-weight: bold;
                font-size: 10px;
            }
        """)
        folder_count_layout.addWidget(folder_count_label)

        self.folder_count_input = QLineEdit()
        self.folder_count_input.setText("8")  # Default value
        self.folder_count_input.setFixedWidth(50)
        self.folder_count_input.setStyleSheet("""
            QLineEdit {
                background-color: white;
                border: 1px solid #3498db;
                border-radius: 4px;
                padding: 4px;
                font-size: 10px;
                color: #2c3e50;
            }
        """)
        folder_count_layout.addWidget(self.folder_count_input)
        folder_count_layout.addStretch()

        left_layout.addWidget(folder_count_frame)

        # Button style mới
        button_style = """
            QPushButton {
                color: #2c3e50;
                background-color: #ffffff;
                border: 2px solid #3498db;
                border-radius: 6px;
                font-weight: bold;
                font-size: 11px;
                min-width: 110px;
                min-height: 30px;
                padding: 5px 10px;
                text-align: center;
            }
            QPushButton:hover {
                background-color: #3498db;
                color: white;
                border: none;
            }
            QPushButton:pressed {
                background-color: #2980b9;
                padding-left: 12px;
            }
        """

        # Button container
        button_container = QFrame()
        button_container.setStyleSheet("""
            QFrame {
                background-color: #f5f6fa;
                border: 1px solid #dcdde1;
                border-radius: 8px;
                padding: 12px;
            }
        """)
        button_layout = QVBoxLayout(button_container)
        button_layout.setSpacing(10)

        # Loading buttons với kích thước cân đối
        loading_layout = QHBoxLayout()
        loading_layout.setSpacing(10)
        
        self.btn_copy_mono = GrayHoverButton("Loading 1stPUC Crop")
        self.btn_copy_mono.setIcon(QIcon(":/icons/loading.png"))
        self.btn_copy_mono.setIconSize(QSize(26, 26))
        self.btn_copy_mono.setStyleSheet(button_style)
        self.btn_copy_mono.clicked.connect(self.copy_logs_mono)
        self.btn_copy_mono.setToolTip(
            "Copy 1st PUC Images\n\n"
            "Process:\n"
            "1. Select date range and lines\n"
            "2. Choose mono folder pattern\n"
            "3. Set number of folders to copy\n"
            "4. System will copy matching TIF files"
        )
        
        self.btn_copy_color = HoverButton("Loading 2ndPUC Crop")
        self.btn_copy_color.setIcon(QIcon(":/icons/loading.png"))
        self.btn_copy_color.setIconSize(QSize(26, 26))
        self.btn_copy_color.setStyleSheet(button_style)
        self.btn_copy_color.clicked.connect(self.copy_logs_color)
        self.btn_copy_color.setToolTip(
            "Copy 2nd PUC Images\n\n"
            "Process:\n"
            "1. Select date range and lines\n"
            "2. Choose color folder pattern\n"
            "3. Set number of folders to copy\n"
            "4. System will copy matching TIF files"
        )
        
        loading_layout.addWidget(self.btn_copy_mono)
        loading_layout.addWidget(self.btn_copy_color)
        button_layout.addLayout(loading_layout)

        # Analysis buttons với kích thước cân đi
        analysis_layout = QHBoxLayout()
        analysis_layout.setSpacing(10)
        
        report_button = HoverButton("Check Intensity")
        report_button.setIcon(QIcon(":/icons/intensity.png"))
        report_button.setIconSize(QSize(26, 26))
        report_button.setStyleSheet(button_style)
        report_button.clicked.connect(self.show_report)
        report_button.setToolTip(
            "Check Image Intensity\n\n"
            "Features:\n"
            "- Analyze Mono/Color patterns\n"
            "- Calculate average intensity\n"
            "- Compare across cameras\n"
            "- Export intensity chart\n\n"
            "Process:\n"
            "1. Select folder with camera subfolders\n"
            "2. Choose pattern types (Mono/Color)\n"
            "3. System calculates average intensity\n"
            "   for matching patterns in each camera"
        )


        # Nút PUC Crop Image Analysis Tool (ẩn các nút detector lẻ)
        all_button = HoverButton("Automatic Image Analysis")
        all_button.setIcon(QIcon(":/icons/image_analysis.png"))
        all_button.setIconSize(QSize(26, 26))
        all_button.setStyleSheet(button_style)
        all_button.clicked.connect(self.show_all_in_one_detector)
        all_button.setToolTip(
            "Run all detectors sequentially\n\n"
            "Process:\n"
            "- HotPixel -> CCD -> Bubble -> LShape\n"
            "- Show summary after completion"
        )

        analysis_layout.addWidget(report_button)
        analysis_layout.addWidget(all_button)
        button_layout.addLayout(analysis_layout)

        # Thêm button container vào left layout
        left_layout.addWidget(button_container)

        # Right panel (Log section)
        right_panel = QFrame()
        right_panel.setMinimumWidth(400)  # Tăng kích thước tối thiểu
        right_panel.setStyleSheet("""
            QFrame {
                background-color: white;
                border: 2px solid #e3e8f0;
                border-radius: 12px;
                padding: 15px;
            }
        """)
        right_layout = QVBoxLayout(right_panel)

        log_label = QLabel("Processing Log")
        log_label.setStyleSheet("""
            QLabel {
                color: #2c3e50;
                font-size: 16px;
                font-weight: bold;
                margin-bottom: 10px;
            }
        """)
        right_layout.addWidget(log_label)

        self.processing_log = QTextEdit()
        self.processing_log.setReadOnly(True)
        self.processing_log.setStyleSheet("""
            QTextEdit {
                background-color: #f8f9fa;
                border: 1px solid #e3e8f0;
                border-radius: 8px;
                padding: 12px;
                font-family: Consolas, monospace;
                font-size: 13px;
                color: #2c3e50;
            }
        """)
        right_layout.addWidget(self.processing_log)

        # Add panels to content layout
        content_layout.addWidget(left_panel, 1)
        content_layout.addWidget(right_panel, 2)
        main_layout.addLayout(content_layout)

        # Footer
        footer_layout = QHBoxLayout()
        author_label = QLabel("Author: nguyenvanvuong1")
        author_label.setStyleSheet("""
            QLabel {
                color: #95a5a6;
                font-size: 12px;
            }
        """)
        footer_layout.addStretch()
        footer_layout.addWidget(author_label)
        main_layout.addLayout(footer_layout)

        # Add shadow effects
        for widget in [header_container, left_panel, right_panel]:
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(15)
            shadow.setXOffset(3)
            shadow.setYOffset(3)
            shadow.setColor(QColor(0, 0, 0, 45))
            widget.setGraphicsEffect(shadow)

        # Thêm shadow effect cho các button
        for button in [self.btn_copy_mono, self.btn_copy_color, report_button, all_button]:
            shadow = QGraphicsDropShadowEffect()
            shadow.setBlurRadius(15)
            shadow.setXOffset(3)
            shadow.setYOffset(3)
            shadow.setColor(QColor(0, 0, 0, 45))
            button.setGraphicsEffect(shadow)

        # Calendar buttons
        self.cal_start.toggle_button.setToolTip("Select Start Date")
        self.cal_end.toggle_button.setToolTip("Select End Date")

        # Comboboxes
        self.mono_combo.setToolTip("Select Mono Pattern Folder")
        self.color_combo.setToolTip("Select Color Pattern Folder")

        # Line checkboxes
        for line, checkbox in self.line_checkboxes.items():
            checkbox.setToolTip(f"Select {line} for processing")

    def center_window(self):
        qr = self.frameGeometry()
        cp = QScreen.availableGeometry(QApplication.primaryScreen()).center()
        qr.moveCenter(cp)
        self.move(qr.topLeft())

    def update_button_states(self):
        # Chỉ cập nhật log khi chọn line
        selected_lines = [line for line, checkbox in self.line_checkboxes.items() if checkbox.isChecked()]
        if selected_lines:
            self.log_process(f"Selected lines: {', '.join(selected_lines)}")
        else:
            self.log_process("No lines selected")

    def copy_logs_mono(self):
        # Thêm logging để debug
        self.log_process("Starting copy_puc_crop_mono...")
        
        # Kiểm tra đã chọn line chưa
        if not any(checkbox.isChecked() for checkbox in self.line_checkboxes.values()):
            QMessageBox.warning(self, "Warning", 
                              "Please select at least one line before copy crop img.")
            self.log_process("No lines selected - aborting")
            return

        # Lấy và log các ngày được chọn
        start_date = self.cal_start.get_selected_date()
        end_date = self.cal_end.get_selected_date()
        self.log_process(f"Date range: {start_date.toString('yyyy-MM-dd')} to {end_date.toString('yyyy-MM-dd')}")

        # Lấy và log các line được chọn
        selected_lines = [line.split()[0] for line, checkbox in self.line_checkboxes.items() 
                         if checkbox.isChecked()]
        self.log_process(f"Selected lines: {selected_lines}")
        
        # Lấy và log folder được chọn
        selected_folder = self.mono_combo.currentText()
        self.log_process(f"Selected folder: {selected_folder}")

        # Lấy số lượng folder
        folder_count = int(self.folder_count_input.text())
        
        confirm_message = (f"Do you want to copy 1stPUC Crop IMG for:\n\n"
                          f"Date Range: {start_date.toString('yyyy-MM-dd')} to {end_date.toString('yyyy-MM-dd')}\n"
                          f"Selected Lines: {', '.join(selected_lines)}\n"
                          f"Selected Folder: {selected_folder}\n"
                          f"Number of Folders to Copy: {folder_count}")
        
        reply = QMessageBox.question(self, 'Confirm Copy',
                                   confirm_message,
                                   QMessageBox.StandardButton.Yes | 
                                   QMessageBox.StandardButton.No,
                                   QMessageBox.StandardButton.Yes)
        
        if reply == QMessageBox.StandardButton.Yes:
            try:
                if folder_count <= 0:
                    QMessageBox.warning(self, "Warning", "Number of folders must be greater than 0")
                    return
                    
                self.clear_log()
                self.log_process("Starting copy process...")
                copy_logs_mono(start_date.toPyDate(), 
                             end_date.toPyDate(), 
                             selected_lines, 
                             selected_folder,
                             folder_count,  # Thêm tham số folder_count
                             log_callback=self.log_process)
                self.log_process("1stPUC logs copying process completed.")
            except Exception as e:
                self.log_process(f"Error during copy: {str(e)}")
                QMessageBox.critical(self, "Error", f"Error during copy: {str(e)}")

    def copy_logs_color(self):
        # Tương tự như copy_logs_mono
        self.log_process("Starting copy_puc_crop_color...")
        
        if not any(checkbox.isChecked() for checkbox in self.line_checkboxes.values()):
            QMessageBox.warning(self, "Warning", 
                              "Please select at least one line before copy crop img.")
            self.log_process("No lines selected - aborting")
            return

        start_date = self.cal_start.get_selected_date()
        end_date = self.cal_end.get_selected_date()
        self.log_process(f"Date range: {start_date.toString('yyyy-MM-dd')} to {end_date.toString('yyyy-MM-dd')}")

        selected_lines = [line.split()[0] for line, checkbox in self.line_checkboxes.items() 
                         if checkbox.isChecked()]
        self.log_process(f"Selected lines: {selected_lines}")
        
        selected_folder = self.color_combo.currentText()
        self.log_process(f"Selected folder: {selected_folder}")

        # Lấy số lượng folder
        folder_count = int(self.folder_count_input.text())
        
        confirm_message = (f"Do you want to copy 2ndPUC Crop IMG for:\n\n"
                          f"Date Range: {start_date.toString('yyyy-MM-dd')} to {end_date.toString('yyyy-MM-dd')}\n"
                          f"Selected Lines: {', '.join(selected_lines)}\n"
                          f"Selected Folder: {selected_folder}\n"
                          f"Number of Folders to Copy: {folder_count}")
        
        reply = QMessageBox.question(self, 'Confirm Copy',
                                   confirm_message,
                                   QMessageBox.StandardButton.Yes | 
                                   QMessageBox.StandardButton.No,
                                   QMessageBox.StandardButton.Yes)
        
        if reply == QMessageBox.StandardButton.Yes:
            try:
                if folder_count <= 0:
                    QMessageBox.warning(self, "Warning", "Number of folders must be greater than 0")
                    return
                    
                self.clear_log()
                self.log_process("Starting copy process...")
                copy_logs_color(start_date.toPyDate(), 
                              end_date.toPyDate(), 
                              selected_lines, 
                              selected_folder,
                              folder_count,  # Thêm tham số folder_count
                              log_callback=self.log_process)
                self.log_process("2ndPUC logs copying process completed.")
            except Exception as e:
                self.log_process(f"Error during copy: {str(e)}")
                QMessageBox.critical(self, "Error", f"Error during copy: {str(e)}")

    def clear_log(self):
        self.processing_log.clear()

    def log_process(self, message):
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        log_message = f"[{current_time}] {message}\n"
        self.processing_log.append(log_message)
        QApplication.processEvents()

    def update_start_date(self):
        start_date = self.cal_start.get_selected_date()
        self.log_process(f"Start date selected: {start_date.toString('yyyy-MM-dd')}")
        self.cal_end.calendar.setMinimumDate(start_date)
        if self.cal_end.get_selected_date() < start_date:
            self.cal_end.set_selected_date(start_date)
        self.cal_end.calendar.updateCells()

    def update_end_date(self):
        end_date = self.cal_end.get_selected_date()
        self.log_process(f"End date selected: {end_date.toString('yyyy-MM-dd')}")

    def manage_lines(self):
        self.apply_blur_effect()
        dialog = LineManagerDialog(self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            # Lưu trạng thái checked của các line hiện tại
            checked_states = {line: checkbox.isChecked() 
                            for line, checkbox in self.line_checkboxes.items()}
            
            # Xóa các checkbox cũ
            self.lines = dialog.get_lines()
            self.update_checkbox_layout()
            # Khôi phục trạng thái checked sau khi cập nhật layout
            for line, checkbox in self.line_checkboxes.items():
                if line in checked_states:
                    checkbox.setChecked(checked_states[line])
        self.remove_blur_effect()

    def load_line_config(self):
        try:
            config = {'lines': ['501 Line', '502 Line', '503 Line', '504 Line'], 
                     'credentials': [{'username': 'user', 'password': '1'}]}
            if os.path.exists('app_config.json'):
                with open('app_config.json', 'r') as f:
                    config = json.load(f)
            self.lines = config.get('lines', ['501 Line', '502 Line', '503 Line', '504 Line'])
            
            # Cập nht UI với layout mới
            self.update_checkbox_layout()
                
        except Exception as e:
            print(f"Error loading line config: {e}")

    def update_checkbox_layout(self):
        try:
            # Tìm container
            checkbox_container = self.findChild(QFrame, "checkbox_container")
            if not checkbox_container:
                return
            
            # Tìm grid layout
            grid_layout = checkbox_container.findChild(QGridLayout, "grid_layout")
            if not grid_layout:
                # Nếu không tìm thấy grid layout, tạo mới
                grid_layout = QGridLayout()
                grid_layout.setSpacing(15)
                grid_layout.setObjectName("grid_layout")
                checkbox_container.layout().addLayout(grid_layout)
            
            # Xóa các checkbox cũ
            while grid_layout.count():
                item = grid_layout.takeAt(0)
                if item.widget():
                    item.widget().deleteLater()
            
            # Tạo lại các checkbox mới
            self.line_checkboxes = {}
            current_row = current_col = 0
            MAX_COLUMNS = 5

            for line in self.lines:
                checkbox = QCheckBox(line)
                checkbox.setIcon(QIcon(":/icons/line.png"))
                checkbox.setIconSize(QSize(16, 16))
                checkbox.setStyleSheet("""
                    QCheckBox {
                        padding: 2px;
                        spacing: 5px;
                        min-width: 100px;
                        max-width: 120px;
                    }
                    QCheckBox:hover {
                        background-color: #e3e8f0;
                        border-radius: 4px;
                    }
                """)
                checkbox.stateChanged.connect(self.update_button_states)
                self.line_checkboxes[line] = checkbox
                
                grid_layout.addWidget(checkbox, current_row, current_col)
                current_col += 1
                if current_col >= MAX_COLUMNS:
                    current_col = 0
                    current_row += 1

            # Force update UI
            checkbox_container.update()
            QApplication.processEvents()

        except Exception as e:
            print(f"Error in update_checkbox_layout: {str(e)}")

    def save_config(self):
        """Lưu toàn bộ config vào file"""
        try:
            config = {
                'lines': self.lines,
                'credentials': self.credentials,
                'mono_folders': self.mono_folders,
                'color_folders': self.color_folders
            }
            with open('app_config.json', 'w') as f:
                json.dump(config, f, indent=4)
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Error saving config: {str(e)}")

    def show_report(self):
        """Hiển thị dialog phân tích intensity"""
        self.apply_blur_effect()
        dialog = IntensityDialog(self)
        dialog.exec()
        self.remove_blur_effect()

    def setup_checkbox_ui(self):
        """Thiết lập lại UI cho phần checkbox"""
        try:
            # Tìm container
            checkbox_container = self.findChild(QFrame, "checkbox_container")
            if not checkbox_container:
                print("Cannot find checkbox container")
                return

            # Tìm grid layout
            grid_layout = checkbox_container.findChild(QGridLayout, "grid_layout")
            if not grid_layout:
                print("Cannot find grid layout")
                return

            # Xóa tất cả checkbox cũ khỏi grid
            while grid_layout.count():
                item = grid_layout.takeAt(0)
                if item.widget():
                    item.widget().deleteLater()

            # Tạo lại các checkbox
            self.line_checkboxes = {}
            current_row = 0
            current_col = 0
            MAX_COLUMNS = 5

            for line in self.lines:
                checkbox = QCheckBox(line)
                checkbox.setIcon(QIcon(":/icons/line.png"))
                checkbox.setIconSize(QSize(16, 16))
                checkbox.setStyleSheet("""
                    QCheckBox {
                        padding: 2px;
                        spacing: 5px;
                        min-width: 100px;
                        max-width: 120px;
                    }
                    QCheckBox:hover {
                        background-color: #e3e8f0;
                        border-radius: 4px;
                    }
                """)
                checkbox.stateChanged.connect(self.update_button_states)
                self.line_checkboxes[line] = checkbox
                
                grid_layout.addWidget(checkbox, current_row, current_col)
                current_col += 1
                if current_col >= MAX_COLUMNS:
                    current_col = 0
                    current_row += 1

            # Cập nhật UI
            checkbox_container.update()
            QApplication.processEvents()

        except Exception as e:
            print(f"Error in setup_checkbox_ui: {str(e)}")

    def refresh_checkboxes(self):
        """Cập nhật nội dung checkbox mà không tạo lại UI"""
        try:
            # Tìm container và grid layout
            checkbox_container = self.findChild(QFrame, "checkbox_container")
            if not checkbox_container:
                print("Cannot find checkbox container")
                return

            # Xóa tất cả widget khỏi grid layout cũ
            grid_layout = checkbox_container.findChild(QGridLayout, "grid_layout")
            if not grid_layout:
                print("Cannot find grid layout")
                return

            # Xóa các widget cũ
            while grid_layout.count():
                item = grid_layout.takeAt(0)
                if item.widget():
                    item.widget().hide()
                    item.widget().deleteLater()

            # Tạo lại các checkbox
            current_row = 0
            current_col = 0
            MAX_COLUMNS = 5

            # Tạo dictionary mới cho checkboxes
            new_checkboxes = {}

            for line in self.lines:
                checkbox = QCheckBox(line, checkbox_container)
                checkbox.setIcon(QIcon(":/icons/line.png"))
                checkbox.setIconSize(QSize(16, 16))
                checkbox.setStyleSheet("""
                    QCheckBox {
                        padding: 2px;
                        spacing: 5px;
                        min-width: 100px;
                        max-width: 120px;
                    }
                    QCheckBox:hover {
                        background-color: #e3e8f0;
                        border-radius: 4px;
                    }
                """)
                checkbox.stateChanged.connect(self.update_button_states)
                checkbox.show()  # Đảm bảo checkbox được hiển thị
                new_checkboxes[line] = checkbox
                
                grid_layout.addWidget(checkbox, current_row, current_col)
                current_col += 1
                if current_col >= MAX_COLUMNS:
                    current_col = 0
                    current_row += 1

            # Cập nhật dictionary checkboxes
            self.line_checkboxes = new_checkboxes

            # Force update UI
            checkbox_container.update()
            grid_layout.update()
            QApplication.processEvents()

        except Exception as e:
            print(f"Error in refresh_checkboxes: {str(e)}")

    def recreate_left_panel(self):
        """Tạo lại toàn bộ left panel"""
        try:
            # Định nghĩa các style chung
            button_style = """
                QPushButton {
                    color: #2c3e50;
                    background-color: #ffffff;
                    border: 2px solid #3498db;
                    border-radius: 6px;
                    font-weight: bold;
                    font-size: 11px;
                    min-width: 120px;
                    min-height: 30px;
                    padding: 5px 10px;
                    text-align: center;
                }
                QPushButton:hover {
                    background-color: #3498db;
                    color: white;
                    border: none;
                }
                QPushButton:pressed {
                    background-color: #2980b9;
                    padding-left: 12px;
                }
            """

            frame_style = """
                QFrame {
                    background-color: #f8f9fa;
                    border: 1px solid #e3e8f0;
                    border-radius: 8px;
                    padding: 12px;
                }
            """

            # Tạo left panel mới
            left_panel = self.create_frame(style="""
                QFrame {
                    background-color: white;
                    border: 2px solid #e3e8f0;
                    border-radius: 12px;
                    padding: 15px;
                }
            """)
            left_panel.setFixedWidth(670)
            left_layout = QVBoxLayout(left_panel)
            left_layout.setSpacing(15)

            # Calendar section
            calendar_container = self.create_frame(style=frame_style)
            calendar_layout = QGridLayout()
            
            self.cal_start = CollapsibleCalendar("Select Start Date")
            self.cal_end = CollapsibleCalendar("Select End Date")
            
            for cal in [self.cal_start, self.cal_end]:
                cal.toggle_button.setIcon(QIcon(":/icons/calendar.png"))
                cal.toggle_button.setIconSize(QSize(20, 20))
            
            self.cal_start.calendar.selectionChanged.connect(self.update_start_date)
            self.cal_end.calendar.selectionChanged.connect(self.update_end_date)
            
            calendar_layout.addWidget(self.cal_start, 0, 0)
            calendar_layout.addWidget(self.cal_end, 0, 1)
            calendar_container.setLayout(calendar_layout)
            left_layout.addWidget(calendar_container)

            # Line Selection
            checkbox_container = self.create_frame(style=frame_style)
            checkbox_container.setObjectName("checkbox_container")
            
            main_checkbox_layout = QVBoxLayout(checkbox_container)
            main_checkbox_layout.setSpacing(8)
            main_checkbox_layout.setContentsMargins(10, 5, 10, 5)

            title_label = self.create_label("Line Selection", """
                QLabel {
                    color: #2c3e50;
                    font-weight: bold;
                    font-size: 11px;
                }
            """)
            main_checkbox_layout.addLayout(title_label)

            grid_layout = QGridLayout()
            grid_layout.setSpacing(15)
            grid_layout.setObjectName("grid_layout")

            self.line_checkboxes = {}
            current_row = current_col = 0
            MAX_COLUMNS = 5

            for line in self.lines:
                checkbox = self.create_checkbox(line, self.update_button_states)
                self.line_checkboxes[line] = checkbox
                grid_layout.addWidget(checkbox, current_row, current_col)
                current_col += 1
                if current_col >= MAX_COLUMNS:
                    current_col = 0
                    current_row += 1

            main_checkbox_layout.addLayout(grid_layout)
            left_layout.addWidget(checkbox_container)

            # Folder Selection
            folder_frame = self.create_frame(height=110, style="""
                QFrame {
                    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, 
                                              stop:0 #f5f6fa, stop:1 #f8f9fa);
                    border: 1px solid #dcdde1;
                    border-radius: 8px;
                    padding: 8px;
                }
            """)

            folder_layout = QGridLayout(folder_frame)
            folder_layout.setSpacing(0)
            folder_layout.setContentsMargins(8, 5, 8, 5)

            # Tạo comboboxes
            self.mono_combo = self.create_combo_box(self.mono_folders)
            self.color_combo = self.create_combo_box(self.color_folders)

            # Thêm vào layout
            folder_layout.addWidget(self.create_label("1stPUC Program Name:"), 0, 0)
            folder_layout.addWidget(self.mono_combo, 0, 1)
            folder_layout.addWidget(self.create_label("2ndPUC Program Name:"), 1, 0)
            folder_layout.addWidget(self.color_combo, 1, 1)

            left_layout.addWidget(folder_frame)

            # Folder Count Selection
            folder_count_frame = self.create_frame(height=50, style="""
                QFrame {
                    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, 
                                              stop:0 #f5f6fa, stop:1 #f8f9fa);
                    border: 1px solid #dcdde1;
                    border-radius: 8px;
                    padding: 8px;
                }
            """)

            folder_count_layout = QHBoxLayout(folder_count_frame)
            folder_count_layout.setContentsMargins(8, 0, 8, 0)

            folder_count_label = self.create_label("Number of folders to copy:", """
                QLabel {
                    color: #2c3e50;
                    font-weight: bold;
                    font-size: 10px;
                }
            """)
            folder_count_layout.addWidget(folder_count_label)

            self.folder_count_input = self.create_line_edit("8", """
                QLineEdit {
                    background-color: white;
                    border: 1px solid #3498db;
                    border-radius: 4px;
                    padding: 4px;
                    font-size: 10px;
                    color: #2c3e50;
                }
            """)
            self.folder_count_input.setFixedWidth(50)
            folder_count_layout.addWidget(self.folder_count_input)
            folder_count_layout.addStretch()

            left_layout.addWidget(folder_count_frame)

            # Button container
            button_container = self.create_frame(style="""
                QFrame {
                    background-color: #f5f6fa;
                    border: 1px solid #dcdde1;
                    border-radius: 8px;
                    padding: 12px;
                }
            """)
            button_layout = QVBoxLayout(button_container)
            button_layout.setSpacing(10)

            # Loading buttons
            self.btn_copy_mono = self.create_button(
                "Loading 1stPUC Crop", 
                ":/icons/loading.png",
                "Copy 1st PUC Images",
                self.copy_logs_mono,
                button_style
            )
            self.btn_copy_color = self.create_button(
                "Loading 2ndPUC Crop",
                ":/icons/loading.png",
                "Copy 2nd PUC Images",
                self.copy_logs_color,
                button_style
            )
            button_layout.addLayout(self.create_button_layout([self.btn_copy_mono, self.btn_copy_color]))

            # Analysis buttons
            report_button = self.create_button(
                "Check Intensity",
                ":/icons/intensity.png",
                "Check Image Intensity",
                self.show_report,
                button_style
            )
            all_button = self.create_button(
                "Image Analysis",
                ":/icons/image_analysis.png",
                "Automatic Image Analysis",
                self.show_report,
                button_style
            )
            button_layout.addLayout(self.create_button_layout([report_button, all_button]))

            left_layout.addWidget(button_container)

            # Thêm left panel mới vào content layout
            content_layout = self.centralWidget().layout().itemAt(1).layout()
            old_left_panel = content_layout.itemAt(0).widget()
            if old_left_panel:
                content_layout.removeWidget(old_left_panel)
                old_left_panel.deleteLater()
            content_layout.insertWidget(0, left_panel)

        except Exception as e:
            print(f"Error in recreate_left_panel: {str(e)}")

    def show_all_in_one_detector(self):
        """Hiển thị cửa sổ PUC Crop Image Analysis Tool"""
        try:
            self.apply_blur_effect()
            if self.all_in_one_detector is None:
                self.all_in_one_detector = combined_detector.MainWindow(self)
                self.all_in_one_detector.setWindowTitle("PUC Crop Image Analysis Tool")
                self.all_in_one_detector.resize(700, 800)

            self.setEnabled(False)
            self.all_in_one_detector.show()
            self.all_in_one_detector.setEnabled(True)
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Error showing PUC Crop Image Analysis Tool: {str(e)}")

    def apply_blur_effect(self):
        blur_effect = QGraphicsBlurEffect(self.centralWidget())
        blur_effect.setBlurRadius(15)
        self.centralWidget().setGraphicsEffect(blur_effect)

    def remove_blur_effect(self):
        self.centralWidget().setGraphicsEffect(None)

    def closeEvent(self, event):
        """Xử lý sự kiện đóng cửa sổ chính"""
        # Đóng các cửa sổ detector nếu đang mở
        if self.all_in_one_detector:
            self.all_in_one_detector.close()
        super().closeEvent(event)
