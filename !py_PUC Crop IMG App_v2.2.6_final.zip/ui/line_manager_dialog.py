from PyQt6.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QListWidget, 
                           QPushButton, QInputDialog, QMessageBox, QLabel,
                           QTabWidget, QWidget, QGridLayout, QLineEdit, QListWidgetItem,
                           QMainWindow, QGraphicsDropShadowEffect, QApplication, QFrame, QCheckBox)
from PyQt6.QtCore import Qt, QSize
from PyQt6.QtGui import QFont, QIcon, QColor
from PyQt6 import QtCore, QtGui, QtWidgets
import json
import os

class CredentialDialog(QDialog):
    def __init__(self, parent=None, username="", password=""):
        super().__init__(parent)
        self.setWindowTitle("Credential Details")
        self.setup_ui(username, password)

    def setup_ui(self, username, password):
        layout = QVBoxLayout(self)
        
        grid = QGridLayout()
        username_label = QLabel("Username:")
        username_label.setFont(QFont("Segoe UI", 12)) # Set font size
        grid.addWidget(username_label, 0, 0)
        self.username_edit = QLineEdit(username)
        self.username_edit.setFont(QFont("Segoe UI", 12)) # Set font size
        grid.addWidget(self.username_edit, 0, 1)
        
        password_label = QLabel("Password:")
        password_label.setFont(QFont("Segoe UI", 12)) # Set font size
        grid.addWidget(password_label, 1, 0)
        self.password_edit = QLineEdit(password)
        self.password_edit.setFont(QFont("Segoe UI", 12)) # Set font size
        self.password_edit.setEchoMode(QLineEdit.EchoMode.Password)
        grid.addWidget(self.password_edit, 1, 1)
        
        layout.addLayout(grid)
        
        btn_layout = QHBoxLayout()
        save_btn = QPushButton("Save")
        save_btn.setFont(QFont("Segoe UI", 12, QFont.Weight.Bold)) # Set font size and bold
        save_btn.clicked.connect(self.accept)
        cancel_btn = QPushButton("Cancel")
        cancel_btn.setFont(QFont("Segoe UI", 12, QFont.Weight.Bold)) # Set font size and bold
        cancel_btn.clicked.connect(self.reject)
        
        btn_layout.addWidget(save_btn)
        btn_layout.addWidget(cancel_btn)
        layout.addLayout(btn_layout)

    def get_credentials(self):
        return self.username_edit.text(), self.password_edit.text()

class LineManagerDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.main_window = parent
        self.setWindowTitle("Preferences")
        self.setWindowIcon(QIcon(":/icons/setting.png"))
        self.resize(550, 650)
        self.setup_ui()
        self.load_lines()
        self.load_credentials()
        self.load_folders()
        # self.load_paths() # Xóa dòng này

    def setup_ui(self):
        layout = QVBoxLayout(self)
        layout.setSpacing(10)
        layout.setContentsMargins(10, 10, 10, 10)

        # Header container với thiết kế hiện đại hơn
        header_container = QtWidgets.QWidget()
        header_container.setFixedHeight(100)  # Tăng chiều cao
        header_container.setStyleSheet("""
            QWidget {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0, 
                                        stop:0 #1f6692, stop:0.5 #3498db, stop:1 #5dade2);
                border-radius: 15px;
                margin: 5px;
            }
        """)

        # Thêm outer glow effect cho header (bóng đổ mạnh hơn)
        header_shadow = QtWidgets.QGraphicsDropShadowEffect()
        header_shadow.setBlurRadius(40)  # Tăng độ mờ
        header_shadow.setXOffset(0)
        header_shadow.setYOffset(6)  # Tăng độ dịch xuống để làm nổi bật hơn
        header_shadow.setColor(QtGui.QColor(52, 152, 219, 120))  # Tăng opacity của bóng
        header_container.setGraphicsEffect(header_shadow)

        header_layout = QtWidgets.QHBoxLayout(header_container)
        header_layout.setContentsMargins(30, 15, 30, 15)
        header_layout.setSpacing(20)

        # Icon trong header với đổ bóng
        icon_button = QtWidgets.QPushButton()
        icon_button.setFixedSize(70, 70)
        icon_button.setCursor(QtGui.QCursor(QtCore.Qt.CursorShape.PointingHandCursor))
        icon_button.setStyleSheet("""
            QPushButton {
                background: transparent;
                border: none;
                border-radius: 25px;
                padding: 10px;
            }
        """)
        
        # Tạo shadow effect cho icon button với độ đậm hơn
        icon_shadow = QtWidgets.QGraphicsDropShadowEffect()
        icon_shadow.setBlurRadius(10)
        icon_shadow.setXOffset(3)
        icon_shadow.setYOffset(3)
        icon_shadow.setColor(QtGui.QColor(0, 0, 0, 80))  # Tăng độ đậm của shadow
        icon_button.setGraphicsEffect(icon_shadow)
        
        # Set icon cho button với kích thước lớn hơn
        icon = QtGui.QIcon(":/icons/setting.png")
        icon_button.setIcon(icon)
        icon_button.setIconSize(QtCore.QSize(70, 70)) 
        
        # Thêm icon button vào header layout
        header_layout.addWidget(icon_button)
        # Text container
        text_container = QtWidgets.QWidget()
        text_container.setStyleSheet("""
            QWidget {
                background: transparent;
            }
            QLabel#title {
                color: white;
                font-family: 'Segoe UI';
                font-size: 25px;  /* Tăng kích thước chữ */
                font-weight: bold;
                padding: 0;
                margin: 0;
                letter-spacing: 1px;
            }
            QLabel#subtitle {
                color: rgba(255, 255, 255, 0.95);
                font-family: 'Segoe UI';
                font-size: 11px;
                font-weight: bold;
                margin-top: 0px;
                padding: 0;
                letter-spacing: 0.5px;
            }
        """)
        text_layout = QtWidgets.QVBoxLayout(text_container)
        text_layout.setSpacing(5)

        title_label = QtWidgets.QLabel("Preferences")
        title_label.setObjectName("title")  # Thêm objectName
        title_label.setAlignment(Qt.AlignmentFlag.AlignLeft)

        subtitle_label = QtWidgets.QLabel("Set up the necessary factors for copying crop images")
        subtitle_label.setObjectName("subtitle")  # Thêm objectName

        text_layout.addWidget(title_label)
        text_layout.addWidget(subtitle_label)
        header_layout.addWidget(text_container)

        header_layout.addStretch()

        layout.addWidget(header_container)

        tab_widget = QTabWidget()
        tab_widget.setStyleSheet("""
            QTabWidget::pane {
                border: 1px solid #e3e8f0;
                border-radius: 6px;
                background: white;
                padding: 8px;
            }
            QTabBar::tab {
                background: #f8f9fa;
                border: 1px solid #e3e8f0;
                padding: 6px 12px;
                margin-right: 2px;
                border-top-left-radius: 4px;
                border-top-right-radius: 4px;
                font-size: 14px;
            }
            QTabBar::tab:selected {
                background: #3498db;
                color: white;
            }
            QListWidget {
                border: 1px solid #e3e8f0;
                border-radius: 4px;
                padding: 3px;
                font-size: 12px; /* Increased from 10px */
            }
            QListWidget::item {
                padding: 4px;
                border-bottom: 1px solid #f8f9fa;
            }
            QListWidget::item:selected {
                background: #e3f2fd;
                color: #2c3e50;
                border-radius: 3px;
            }
            QPushButton {
                background-color: white;
                border: 1px solid #3498db;
                border-radius: 3px;
                padding: 3px 10px;
                color: #2c3e50;
                font-size: 12px; /* Increased from 10px */
                min-height: 20px;
                max-height: 20px;
            }
            QPushButton:hover {
                background-color: #3498db;
                color: white;
            }
            QLabel {
                color: #2c3e50;
                font-size: 12px; /* Increased from 10px */
                font-weight: bold;
            }
        """)

        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(6)
        shadow.setXOffset(1)
        shadow.setYOffset(1)
        shadow.setColor(QColor(0, 0, 0, 20))
        header_container.setGraphicsEffect(shadow)

        # Lines Tab
        lines_tab = QWidget()
        lines_layout = QVBoxLayout(lines_tab)
        lines_layout.setSpacing(10)

        # Khởi tạo list widget cho Lines
        self.list_widget = QListWidget()
        lines_layout.addWidget(self.list_widget)

        # Lines Buttons
        lines_button_layout = QHBoxLayout()
        add_line_btn = QPushButton("Add")
        add_line_btn.setIcon(QIcon(":/icons/add.png"))
        add_line_btn.setIconSize(QSize(12, 12))
        add_line_btn.clicked.connect(self.add_line)
        
        edit_line_btn = QPushButton("Edit")
        edit_line_btn.setIcon(QIcon(":/icons/editing.png"))
        edit_line_btn.setIconSize(QSize(12, 12))
        edit_line_btn.clicked.connect(self.edit_line)
        
        delete_line_btn = QPushButton("Delete")
        delete_line_btn.setIcon(QIcon(":/icons/delete.png"))
        delete_line_btn.setIconSize(QSize(12, 12))
        delete_line_btn.clicked.connect(self.delete_line)

        lines_button_layout.addWidget(add_line_btn)
        lines_button_layout.addWidget(edit_line_btn)
        lines_button_layout.addWidget(delete_line_btn)
        lines_layout.addLayout(lines_button_layout)

        # Folders Tab
        folders_tab = QWidget()
        folders_layout = QVBoxLayout(folders_tab)
        folders_layout.setSpacing(10)

        # 1stPUC Folders
        mono_group = QWidget()
        mono_layout = QVBoxLayout(mono_group)
        mono_layout.setSpacing(8)
        
        mono_label = QLabel("1stPUC Folders")
        mono_layout.addWidget(mono_label)

        # Khởi tạo list widget cho Mono folders
        self.mono_list = QListWidget()
        mono_layout.addWidget(self.mono_list)

        mono_buttons = QHBoxLayout()
        add_mono_btn = QPushButton("Add")
        add_mono_btn.setIcon(QIcon(":/icons/add.png"))
        add_mono_btn.setIconSize(QSize(12, 12))
        add_mono_btn.clicked.connect(lambda: self.add_folder("mono"))
        
        edit_mono_btn = QPushButton("Edit")
        edit_mono_btn.setIcon(QIcon(":/icons/editing.png"))
        edit_mono_btn.setIconSize(QSize(12, 12))
        edit_mono_btn.clicked.connect(lambda: self.edit_folder("mono"))
        
        delete_mono_btn = QPushButton("Delete")
        delete_mono_btn.setIcon(QIcon(":/icons/delete.png"))
        delete_mono_btn.setIconSize(QSize(12, 12))
        delete_mono_btn.clicked.connect(lambda: self.delete_folder("mono"))

        mono_buttons.addWidget(add_mono_btn)
        mono_buttons.addWidget(edit_mono_btn)
        mono_buttons.addWidget(delete_mono_btn)
        mono_layout.addLayout(mono_buttons)
        folders_layout.addWidget(mono_group)

        # 2ndPUC Folders
        color_group = QWidget()
        color_layout = QVBoxLayout(color_group)
        color_layout.setSpacing(8)
        
        color_label = QLabel("2ndPUC Folders")
        color_layout.addWidget(color_label)

        # Khởi tạo list widget cho Color folders
        self.color_list = QListWidget()
        color_layout.addWidget(self.color_list)

        color_buttons = QHBoxLayout()
        add_color_btn = QPushButton("Add")
        add_color_btn.setIcon(QIcon(":/icons/add.png"))
        add_color_btn.setIconSize(QSize(12, 12))
        add_color_btn.clicked.connect(lambda: self.add_folder("color"))
        
        edit_color_btn = QPushButton("Edit")
        edit_color_btn.setIcon(QIcon(":/icons/editing.png"))
        edit_color_btn.setIconSize(QSize(12, 12))
        edit_color_btn.clicked.connect(lambda: self.edit_folder("color"))
        
        delete_color_btn = QPushButton("Delete")
        delete_color_btn.setIcon(QIcon(":/icons/delete.png"))
        delete_color_btn.setIconSize(QSize(12, 12))
        delete_color_btn.clicked.connect(lambda: self.delete_folder("color"))

        color_buttons.addWidget(add_color_btn)
        color_buttons.addWidget(edit_color_btn)
        color_buttons.addWidget(delete_color_btn)
        color_layout.addLayout(color_buttons)
        folders_layout.addWidget(color_group)

        # Credentials Tab
        credentials_tab = QWidget()
        credentials_layout = QVBoxLayout(credentials_tab)
        credentials_layout.setSpacing(10)

        # Khởi tạo list widget cho Credentials
        self.cred_list = QListWidget()
        credentials_layout.addWidget(self.cred_list)

        cred_buttons = QHBoxLayout()
        add_cred_btn = QPushButton("Add")
        add_cred_btn.setIcon(QIcon(":/icons/add.png"))
        add_cred_btn.setIconSize(QSize(12, 12))
        add_cred_btn.clicked.connect(self.add_credential)
        
        edit_cred_btn = QPushButton("Edit")
        edit_cred_btn.setIcon(QIcon(":/icons/editing.png"))
        edit_cred_btn.setIconSize(QSize(12, 12))
        edit_cred_btn.clicked.connect(self.edit_credential)
        
        delete_cred_btn = QPushButton("Delete")
        delete_cred_btn.setIcon(QIcon(":/icons/delete.png"))
        delete_cred_btn.setIconSize(QSize(12, 12))
        delete_cred_btn.clicked.connect(self.delete_credential)

        cred_buttons.addWidget(add_cred_btn)
        cred_buttons.addWidget(edit_cred_btn)
        cred_buttons.addWidget(delete_cred_btn)
        credentials_layout.addLayout(cred_buttons)

        # Add tabs to tab widget
        tab_widget.addTab(lines_tab, "Lines")
        tab_widget.addTab(folders_tab, "Folders")
        tab_widget.addTab(credentials_tab, "Credentials")
        # tab_widget.addTab(path_tab, "Path Settings") # Xóa dòng này

        layout.addWidget(tab_widget)

        # Save and Close button with modern style
        self.save_close_btn = QPushButton("Save & Close")
        self.save_close_btn.setObjectName("save_close_btn")
        self.save_close_btn.setFont(QFont("Segoe UI", 13, QFont.Weight.Bold)) # Increased font size
        self.save_close_btn.setStyleSheet("""
            QPushButton {
                background-color: #3498db;
                color: white;
                border: none;
                border-radius: 8px;
                padding: 12px 30px;
                font-size: 14px;
                font-weight: bold;
                min-width: 120px;
            }
            QPushButton:hover {
                background-color: #2980b9;
            }
            QPushButton:pressed {
                background-color: #2472a4;
                padding-top: 14px;
            }
        """)
        # Add shadow effect to the save_close_btn
        save_close_shadow = QGraphicsDropShadowEffect()
        save_close_shadow.setBlurRadius(15)
        save_close_shadow.setXOffset(3)
        save_close_shadow.setYOffset(3)
        save_close_shadow.setColor(QColor(0, 0, 0, 80)) # Stronger shadow
        self.save_close_btn.setGraphicsEffect(save_close_shadow)
        
        self.save_close_btn.clicked.connect(self.save_and_close)
        layout.addWidget(self.save_close_btn)

    def load_credentials(self):
        try:
            config = {'lines': [], 'credentials': [{'username': 'user', 'password': '1'}]}
            if os.path.exists('app_config.json'):
                with open('app_config.json', 'r') as f:
                    config = json.load(f)
            self.credentials = config.get('credentials', [{'username': 'user', 'password': '1'}])
            self.update_credential_list()
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Error loading credentials: {str(e)}")

    def update_credential_list(self):
        self.cred_list.clear()
        for cred in self.credentials:
            item = QListWidgetItem(f"Username: {cred['username']}")
            self.cred_list.addItem(item)

    def add_credential(self):
        dialog = CredentialDialog(self)
        if dialog.exec() == QDialog.DialogCode.Accepted:
            username, password = dialog.get_credentials()
            if username and password:
                self.credentials.append({'username': username, 'password': password})
                self.update_credential_list()

    def edit_credential(self):
        current_item = self.cred_list.currentRow()
        if current_item >= 0:
            cred = self.credentials[current_item]
            dialog = CredentialDialog(self, cred['username'], cred['password'])
            if dialog.exec() == QDialog.DialogCode.Accepted:
                username, password = dialog.get_credentials()
                if username and password:
                    self.credentials[current_item] = {'username': username, 'password': password}
                    self.update_credential_list()
        else:
            QMessageBox.warning(self, "Warning", "Please select a credential to edit")

    def delete_credential(self):
        current_item = self.cred_list.currentRow()
        if current_item >= 0:
            reply = QMessageBox.question(self, 'Confirm Delete',
                                       'Are you sure you want to delete this credential?',
                                       QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
            if reply == QMessageBox.StandardButton.Yes:
                self.credentials.pop(current_item)
                self.update_credential_list()
        else:
            QMessageBox.warning(self, "Warning", "Please select a credential to delete")

    def save_credentials(self):
        try:
            config = {'lines': [], 'credentials': []}
            if os.path.exists('app_config.json'):
                with open('app_config.json', 'r') as f:
                    config = json.load(f)
            config['credentials'] = self.credentials
            with open('app_config.json', 'w') as f:
                json.dump(config, f, indent=4)
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Error saving credentials: {str(e)}")

    def save_and_close(self):
        """Save all settings and close dialog"""
        try:
            # Save lines
            current_lines = [self.list_widget.item(i).text() 
                           for i in range(self.list_widget.count())]
            self.save_lines(current_lines)
            
            # Save credentials
            self.save_credentials()
            
            # Save folders
            self.save_folders()
                      
            # Cập nhật UI của main window nếu cần
            if self.main_window is not None:
                # Cập nhật lines
                self.main_window.lines = current_lines.copy()
                
                # Cập nhật UI của main window
                self.main_window.update_checkbox_layout()
            
            self.accept()
            
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Error saving settings: {str(e)}")

    def load_lines(self):
        try:
            config = {'lines': ['501 Line', '502 Line', '503 Line', '504 Line'], 
                     'credentials': [{'username': 'user', 'password': '1'}]}
            if os.path.exists('app_config.json'):
                with open('app_config.json', 'r') as f:
                    config = json.load(f)
            lines = config.get('lines', ['501 Line', '502 Line', '503 Line', '504 Line'])
            self.list_widget.clear()
            self.list_widget.addItems(lines)
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Error loading lines: {str(e)}")

    def save_lines(self, lines):
        try:
            config = {'lines': [], 'credentials': []}
            if os.path.exists('app_config.json'):
                with open('app_config.json', 'r') as f:
                    config = json.load(f)
            config['lines'] = lines
            with open('app_config.json', 'w') as f:
                json.dump(config, f, indent=4)
            
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Error saving lines: {str(e)}")

    def add_line(self):
        line, ok = QInputDialog.getText(self, "Add Line", 
                                      "Enter new line name (e.g., '505 Line'):",
                                      text="Line")
        if ok and line:
            if not line.strip().endswith('Line'):
                line = f"{line.strip()} Line"
            current_lines = [self.list_widget.item(i).text() 
                           for i in range(self.list_widget.count())]
            if line not in current_lines:
                try:
                    self.list_widget.addItem(line)
                    # Cập nhật UI ngay lập tức nếu cần
                    if self.main_window is not None:
                        new_lines = [self.list_widget.item(i).text() 
                                   for i in range(self.list_widget.count())]
                        self.main_window.lines = new_lines.copy()
                        self.main_window.update_checkbox_layout()
                except Exception as e:
                    QMessageBox.warning(self, "Error", f"Error adding line: {str(e)}")
            else:
                QMessageBox.warning(self, "Warning", "This line already exists!")

    def edit_line(self):
        current_item = self.list_widget.currentItem()
        if current_item:
            new_line, ok = QInputDialog.getText(self, "Edit Line", 
                                              "Edit line name:",
                                              text=current_item.text())
            if ok and new_line:
                if not new_line.strip().endswith('Line'):
                    new_line = f"{new_line.strip()} Line"
                current_item.setText(new_line)
                # Lưu lines mới
                new_lines = [self.list_widget.item(i).text() 
                            for i in range(self.list_widget.count())]
                self.save_lines(new_lines)
                
                # Cập nhật lines trong main window
                if self.main_window is not None:
                    self.main_window.lines = new_lines
                    # Cập nhật UI ngay lập tức
                    self.main_window.update_checkbox_layout()
        else:
            QMessageBox.warning(self, "Warning", "Please select a line to edit!")

    def delete_line(self):
        current_item = self.list_widget.currentItem()
        if current_item:
            reply = QMessageBox.question(self, "Confirm Delete",
                                       f"Are you sure you want to delete {current_item.text()}?",
                                       QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
            if reply == QMessageBox.StandardButton.Yes:
                self.list_widget.takeItem(self.list_widget.row(current_item))
                # Lưu lines mới
                new_lines = [self.list_widget.item(i).text() 
                            for i in range(self.list_widget.count())]
                self.save_lines(new_lines)
                
                # Cập nhật lines trong main window
                if self.main_window is not None:
                    self.main_window.lines = new_lines
                    # Cập nhật UI ngay lập tức
                    self.main_window.update_checkbox_layout()
        else:
            QMessageBox.warning(self, "Warning", "Please select a line to delete!")

    def get_lines(self):
        return [self.list_widget.item(i).text() 
                for i in range(self.list_widget.count())] 

    def load_folders(self):
        try:
            config = {'lines': [], 'credentials': [], 
                     'mono_folders': [], 'color_folders': []}
            
            if os.path.exists('app_config.json'):
                with open('app_config.json', 'r') as f:
                    config = json.load(f)
            
            # Lấy giá trị mặc định từ main window nếu có
            default_mono_folders = []
            default_color_folders = []
            if self.main_window is not None:
                default_mono_folders = self.main_window.mono_folders
                default_color_folders = self.main_window.color_folders
            
            # Lấy giá trị từ config hoặc sử dụng giá trị mặc định
            mono_folders = config.get('mono_folders', default_mono_folders)
            color_folders = config.get('color_folders', default_color_folders)
            
            # Cập nhật UI
            self.mono_list.clear()
            self.mono_list.addItems(mono_folders)
            
            self.color_list.clear()
            self.color_list.addItems(color_folders)
            
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Error loading folders: {str(e)}")

    def add_folder(self, folder_type):
        title = "1stPUC" if folder_type == "mono" else "2ndPUC"
        folder, ok = QInputDialog.getText(self, f"Add {title} Folder", 
                                        f"Enter new folder name:")
        if ok and folder:
            list_widget = self.mono_list if folder_type == "mono" else self.color_list
            
            existing_folders = [list_widget.item(i).text() 
                              for i in range(list_widget.count())]
            
            if folder in existing_folders:
                QMessageBox.warning(
                    self, 
                    "Warning", 
                    f"Folder '{folder}' already exists!\n\nPlease enter a different folder name."
                )
                return
            
            list_widget.addItem(folder)
            self.save_folders()

    def edit_folder(self, folder_type):
        list_widget = self.mono_list if folder_type == "mono" else self.color_list
        current_item = list_widget.currentItem()
        if current_item:
            title = "1stPUC" if folder_type == "mono" else "2ndPUC"
            new_folder, ok = QInputDialog.getText(self, f"Edit {title} Folder", 
                                                "Edit folder name:",
                                                text=current_item.text())
            if ok and new_folder:
                existing_folders = [list_widget.item(i).text() 
                                  for i in range(list_widget.count())
                                  if list_widget.item(i) != current_item]
                
                if new_folder in existing_folders:
                    QMessageBox.warning(
                        self, 
                        "Warning", 
                        f"Folder '{new_folder}' already exists!\n\nPlease enter a different folder name."
                    )
                    return
                
                current_item.setText(new_folder)
                self.save_folders()
        else:
            QMessageBox.warning(self, "Warning", "Please select a folder to edit!")

    def delete_folder(self, folder_type):
        list_widget = self.mono_list if folder_type == "mono" else self.color_list
        current_item = list_widget.currentItem()
        if current_item:
            reply = QMessageBox.question(self, "Confirm Delete",
                                       f"Are you sure you want to delete this folder?",
                                       QMessageBox.StandardButton.Yes | 
                                       QMessageBox.StandardButton.No)
            if reply == QMessageBox.StandardButton.Yes:
                list_widget.takeItem(list_widget.row(current_item))
                self.save_folders()
        else:
            QMessageBox.warning(self, "Warning", "Please select a folder to delete!")

    def save_folders(self):
        try:
            config = {}
            if os.path.exists('app_config.json'):
                with open('app_config.json', 'r') as f:
                    config = json.load(f)
            
            # Lấy giá trị hiện tại từ list widgets
            config['mono_folders'] = [self.mono_list.item(i).text() 
                                    for i in range(self.mono_list.count())]
            config['color_folders'] = [self.color_list.item(i).text() 
                                     for i in range(self.color_list.count())]
            
            # Lưu config
            with open('app_config.json', 'w') as f:
                json.dump(config, f, indent=4)
                
            # Cập nhật main window nếu có
            if self.main_window is not None:
                self.main_window.mono_folders = config['mono_folders']
                self.main_window.color_folders = config['color_folders']
                self.main_window.mono_combo.clear()
                self.main_window.mono_combo.addItems(config['mono_folders'])
                self.main_window.color_combo.clear()
                self.main_window.color_combo.addItems(config['color_folders'])
                    
        except Exception as e:
            QMessageBox.warning(self, "Error", f"Error saving folders: {str(e)}")

